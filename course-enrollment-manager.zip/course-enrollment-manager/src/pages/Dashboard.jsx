import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getAll } from '../api.js';
import Alert from '../components/Alert.jsx';

export default function Dashboard() {
  const [counts, setCounts] = useState({ students: 0, courses: 0, enrollments: 0 });
  const [error, setError] = useState('');

  useEffect(() => {
    Promise.all([getAll('students'), getAll('courses'), getAll('enrollments')])
      .then(([s, c, e]) => setCounts({ students: s.length, courses: c.length, enrollments: e.length }))
      .catch(() => setError('Cannot reach the API. Start JSON Server with "npm run api".'));
  }, []);

  const cards = [
    { label: 'Students', value: counts.students, to: '/students' },
    { label: 'Courses', value: counts.courses, to: '/courses' },
    { label: 'Enrollments', value: counts.enrollments, to: '/enrollments' },
  ];

  return (
    <>
      <h2 className="mb-3">Dashboard</h2>
      <Alert message={error} />
      <div className="row g-3">
        {cards.map((c) => (
          <div className="col-12 col-md-4" key={c.label}>
            <div className="card stat-card h-100">
              <div className="card-body">
                <div className="text-muted">{c.label}</div>
                <div className="stat-number">{c.value}</div>
                <Link to={c.to}>Manage {c.label.toLowerCase()} &rarr;</Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
