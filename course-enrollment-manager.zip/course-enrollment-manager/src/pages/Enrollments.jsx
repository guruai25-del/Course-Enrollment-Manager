import { useEffect, useState } from 'react';
import { getAll, create, update, remove } from '../api.js';
import Alert from '../components/Alert.jsx';

const today = () => new Date().toISOString().slice(0, 10);
const empty = () => ({ studentId: '', courseId: '', enrolledOn: today(), status: 'Active' });

export default function Enrollments() {
  const [enrollments, setEnrollments] = useState([]);
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState(empty());
  const [editingId, setEditingId] = useState(null);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState({ type: 'danger', text: '' });

  const load = () =>
    Promise.all([getAll('enrollments'), getAll('students'), getAll('courses')])
      .then(([e, s, c]) => { setEnrollments(e); setStudents(s); setCourses(c); })
      .catch(() => setMessage({ type: 'danger', text: 'Failed to load data. Is JSON Server running?' }));

  useEffect(() => { load(); }, []);

  const studentName = (id) => students.find((s) => s.id === id)?.name ?? 'Unknown';
  const courseTitle = (id) => courses.find((c) => c.id === id)?.title ?? 'Unknown';

  const validate = () => {
    const e = {};
    if (!form.studentId) e.studentId = 'Select a student.';
    if (!form.courseId) e.courseId = 'Select a course.';
    if (!form.enrolledOn) e.enrolledOn = 'Pick a date.';
    if (
      form.studentId && form.courseId &&
      enrollments.some(
        (en) => en.studentId === Number(form.studentId) && en.courseId === Number(form.courseId) && en.id !== editingId
      )
    ) e.courseId = 'This student is already enrolled in this course.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    const payload = { ...form, studentId: Number(form.studentId), courseId: Number(form.courseId) };
    try {
      if (editingId) {
        await update('enrollments', editingId, { ...payload, id: editingId });
        setMessage({ type: 'success', text: 'Enrollment updated.' });
      } else {
        await create('enrollments', payload);
        setMessage({ type: 'success', text: 'Student enrolled.' });
      }
      setForm(empty());
      setEditingId(null);
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not save the enrollment.' });
    }
  };

  const handleEdit = (en) => {
    setEditingId(en.id);
    setForm({ studentId: String(en.studentId), courseId: String(en.courseId), enrolledOn: en.enrolledOn, status: en.status });
    setErrors({});
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (en) => {
    if (!window.confirm('Cancel this enrollment?')) return;
    try {
      await remove('enrollments', en.id);
      setMessage({ type: 'success', text: 'Enrollment cancelled.' });
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not cancel the enrollment.' });
    }
  };

  const cancelEdit = () => { setEditingId(null); setForm(empty()); setErrors({}); };

  return (
    <>
      <h2 className="mb-3">Enrollments</h2>
      <Alert type={message.type} message={message.text} onClose={() => setMessage({ ...message, text: '' })} />

      <div className="card table-card mb-4">
        <div className="card-body">
          <h5 className="card-title">{editingId ? 'Edit enrollment' : 'Enroll a student'}</h5>
          <form onSubmit={handleSubmit} noValidate>
            <div className="row g-3">
              <div className="col-12 col-md-3">
                <label className="form-label" htmlFor="studentId">Student</label>
                <select id="studentId" name="studentId" className={`form-select ${errors.studentId ? 'is-invalid' : ''}`} value={form.studentId} onChange={handleChange}>
                  <option value="">-- Select --</option>
                  {students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                </select>
                {errors.studentId && <div className="form-error">{errors.studentId}</div>}
              </div>
              <div className="col-12 col-md-3">
                <label className="form-label" htmlFor="courseId">Course</label>
                <select id="courseId" name="courseId" className={`form-select ${errors.courseId ? 'is-invalid' : ''}`} value={form.courseId} onChange={handleChange}>
                  <option value="">-- Select --</option>
                  {courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
                </select>
                {errors.courseId && <div className="form-error">{errors.courseId}</div>}
              </div>
              <div className="col-6 col-md-3">
                <label className="form-label" htmlFor="enrolledOn">Date</label>
                <input id="enrolledOn" name="enrolledOn" type="date" className={`form-control ${errors.enrolledOn ? 'is-invalid' : ''}`} value={form.enrolledOn} onChange={handleChange} />
                {errors.enrolledOn && <div className="form-error">{errors.enrolledOn}</div>}
              </div>
              <div className="col-6 col-md-3">
                <label className="form-label" htmlFor="status">Status</label>
                <select id="status" name="status" className="form-select" value={form.status} onChange={handleChange}>
                  <option>Active</option>
                  <option>Completed</option>
                </select>
              </div>
            </div>
            <div className="mt-3">
              <button type="submit" className="btn btn-primary me-2">{editingId ? 'Update' : 'Enroll'}</button>
              {editingId && <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit}>Cancel</button>}
            </div>
          </form>
        </div>
      </div>

      <div className="card table-card">
        <div className="card-body">
          <h5 className="card-title">All enrollments ({enrollments.length})</h5>
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-light">
                <tr><th>ID</th><th>Student</th><th>Course</th><th>Date</th><th>Status</th><th className="text-end">Actions</th></tr>
              </thead>
              <tbody>
                {enrollments.length === 0 && <tr><td colSpan="6" className="text-center text-muted">No enrollments yet.</td></tr>}
                {enrollments.map((en) => (
                  <tr key={en.id}>
                    <td>{en.id}</td>
                    <td>{studentName(en.studentId)}</td>
                    <td>{courseTitle(en.courseId)}</td>
                    <td>{en.enrolledOn}</td>
                    <td><span className={`badge ${en.status === 'Active' ? 'bg-success' : 'bg-secondary'}`}>{en.status}</span></td>
                    <td className="text-end">
                      <button className="btn btn-sm btn-outline-primary me-2" onClick={() => handleEdit(en)}>Edit</button>
                      <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(en)}>Cancel</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
