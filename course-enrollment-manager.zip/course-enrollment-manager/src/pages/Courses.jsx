import { useEffect, useState } from 'react';
import { getAll, create, update, remove } from '../api.js';
import Alert from '../components/Alert.jsx';

const empty = { title: '', duration: '', fee: '' };

export default function Courses() {
  const [courses, setCourses] = useState([]);
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState(null);
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState({ type: 'danger', text: '' });

  const load = () =>
    getAll('courses')
      .then(setCourses)
      .catch(() => setMessage({ type: 'danger', text: 'Failed to load courses. Is JSON Server running?' }));

  useEffect(() => { load(); }, []);

  const validate = () => {
    const e = {};
    if (form.title.trim().length < 3) e.title = 'Title must be at least 3 characters.';
    if (!form.duration.trim()) e.duration = 'Duration is required (e.g. 6 weeks).';
    if (form.fee === '' || Number(form.fee) <= 0) e.fee = 'Fee must be a positive number.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    const payload = { ...form, fee: Number(form.fee) };
    try {
      if (editingId) {
        await update('courses', editingId, { ...payload, id: editingId });
        setMessage({ type: 'success', text: 'Course updated.' });
      } else {
        await create('courses', payload);
        setMessage({ type: 'success', text: 'Course added.' });
      }
      setForm(empty);
      setEditingId(null);
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not save the course.' });
    }
  };

  const handleEdit = (c) => {
    setEditingId(c.id);
    setForm({ title: c.title, duration: c.duration, fee: String(c.fee) });
    setErrors({});
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (c) => {
    if (!window.confirm(`Delete course "${c.title}"? Its enrollments will also be removed.`)) return;
    try {
      const enrollments = await getAll('enrollments');
      await Promise.all(enrollments.filter((en) => en.courseId === c.id).map((en) => remove('enrollments', en.id)));
      await remove('courses', c.id);
      setMessage({ type: 'success', text: 'Course deleted.' });
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not delete the course.' });
    }
  };

  const cancelEdit = () => { setEditingId(null); setForm(empty); setErrors({}); };

  return (
    <>
      <h2 className="mb-3">Courses</h2>
      <Alert type={message.type} message={message.text} onClose={() => setMessage({ ...message, text: '' })} />

      <div className="card table-card mb-4">
        <div className="card-body">
          <h5 className="card-title">{editingId ? 'Edit course' : 'Add course'}</h5>
          <form onSubmit={handleSubmit} noValidate>
            <div className="row g-3">
              <div className="col-12 col-md-5">
                <label className="form-label" htmlFor="title">Title</label>
                <input id="title" name="title" className={`form-control ${errors.title ? 'is-invalid' : ''}`} value={form.title} onChange={handleChange} />
                {errors.title && <div className="form-error">{errors.title}</div>}
              </div>
              <div className="col-6 col-md-4">
                <label className="form-label" htmlFor="duration">Duration</label>
                <input id="duration" name="duration" className={`form-control ${errors.duration ? 'is-invalid' : ''}`} value={form.duration} onChange={handleChange} />
                {errors.duration && <div className="form-error">{errors.duration}</div>}
              </div>
              <div className="col-6 col-md-3">
                <label className="form-label" htmlFor="fee">Fee (₹)</label>
                <input id="fee" name="fee" type="number" className={`form-control ${errors.fee ? 'is-invalid' : ''}`} value={form.fee} onChange={handleChange} />
                {errors.fee && <div className="form-error">{errors.fee}</div>}
              </div>
            </div>
            <div className="mt-3">
              <button type="submit" className="btn btn-primary me-2">{editingId ? 'Update' : 'Add'}</button>
              {editingId && <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit}>Cancel</button>}
            </div>
          </form>
        </div>
      </div>

      <div className="card table-card">
        <div className="card-body">
          <h5 className="card-title">All courses ({courses.length})</h5>
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-light">
                <tr><th>ID</th><th>Title</th><th>Duration</th><th>Fee (₹)</th><th className="text-end">Actions</th></tr>
              </thead>
              <tbody>
                {courses.length === 0 && <tr><td colSpan="5" className="text-center text-muted">No courses found.</td></tr>}
                {courses.map((c) => (
                  <tr key={c.id}>
                    <td>{c.id}</td><td>{c.title}</td><td>{c.duration}</td><td>{c.fee}</td>
                    <td className="text-end">
                      <button className="btn btn-sm btn-outline-primary me-2" onClick={() => handleEdit(c)}>Edit</button>
                      <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(c)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
