import { useEffect, useState } from 'react';
import { getAll, create, update, remove } from '../api.js';
import Alert from '../components/Alert.jsx';

const empty = { name: '', email: '', phone: '' };

export default function Students() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState(empty);
  const [editingId, setEditingId] = useState(null);
  const [errors, setErrors] = useState({});
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState({ type: 'danger', text: '' });

  const load = () =>
    getAll('students')
      .then(setStudents)
      .catch(() => setMessage({ type: 'danger', text: 'Failed to load students. Is JSON Server running?' }));

  useEffect(() => { load(); }, []);

  const validate = () => {
    const e = {};
    if (form.name.trim().length < 3) e.name = 'Name must be at least 3 characters.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address.';
    if (!/^\d{10}$/.test(form.phone)) e.phone = 'Phone must be exactly 10 digits.';
    else if (students.some((s) => s.email === form.email && s.id !== editingId)) e.email = 'Email already exists.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    try {
      if (editingId) {
        await update('students', editingId, { ...form, id: editingId });
        setMessage({ type: 'success', text: 'Student updated.' });
      } else {
        await create('students', form);
        setMessage({ type: 'success', text: 'Student added.' });
      }
      setForm(empty);
      setEditingId(null);
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not save the student.' });
    }
  };

  const handleEdit = (s) => {
    setEditingId(s.id);
    setForm({ name: s.name, email: s.email, phone: s.phone });
    setErrors({});
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (s) => {
    if (!window.confirm(`Delete ${s.name}? Their enrollments will also be removed.`)) return;
    try {
      const enrollments = await getAll('enrollments');
      await Promise.all(enrollments.filter((en) => en.studentId === s.id).map((en) => remove('enrollments', en.id)));
      await remove('students', s.id);
      setMessage({ type: 'success', text: 'Student deleted.' });
      load();
    } catch {
      setMessage({ type: 'danger', text: 'Could not delete the student.' });
    }
  };

  const cancelEdit = () => { setEditingId(null); setForm(empty); setErrors({}); };

  const visible = students.filter((s) =>
    `${s.name} ${s.email}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <h2 className="mb-3">Students</h2>
      <Alert type={message.type} message={message.text} onClose={() => setMessage({ ...message, text: '' })} />

      <div className="card table-card mb-4">
        <div className="card-body">
          <h5 className="card-title">{editingId ? 'Edit student' : 'Add student'}</h5>
          <form onSubmit={handleSubmit} noValidate>
            <div className="row g-3">
              <div className="col-12 col-md-4">
                <label className="form-label" htmlFor="name">Name</label>
                <input id="name" name="name" className={`form-control ${errors.name ? 'is-invalid' : ''}`} value={form.name} onChange={handleChange} />
                {errors.name && <div className="form-error">{errors.name}</div>}
              </div>
              <div className="col-12 col-md-4">
                <label className="form-label" htmlFor="email">Email</label>
                <input id="email" name="email" type="email" className={`form-control ${errors.email ? 'is-invalid' : ''}`} value={form.email} onChange={handleChange} />
                {errors.email && <div className="form-error">{errors.email}</div>}
              </div>
              <div className="col-12 col-md-4">
                <label className="form-label" htmlFor="phone">Phone</label>
                <input id="phone" name="phone" className={`form-control ${errors.phone ? 'is-invalid' : ''}`} value={form.phone} onChange={handleChange} />
                {errors.phone && <div className="form-error">{errors.phone}</div>}
              </div>
            </div>
            <div className="mt-3">
              <button type="submit" className="btn btn-primary me-2">{editingId ? 'Update' : 'Add'}</button>
              {editingId && <button type="button" className="btn btn-outline-secondary" onClick={cancelEdit}>Cancel</button>}
            </div>
          </form>
        </div>
      </div>

      <div className="card table-card">
        <div className="card-body">
          <div className="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
            <h5 className="card-title mb-0">All students ({visible.length})</h5>
            <input className="form-control w-auto" placeholder="Search name or email" value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-light">
                <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th className="text-end">Actions</th></tr>
              </thead>
              <tbody>
                {visible.length === 0 && <tr><td colSpan="5" className="text-center text-muted">No students found.</td></tr>}
                {visible.map((s) => (
                  <tr key={s.id}>
                    <td>{s.id}</td><td>{s.name}</td><td>{s.email}</td><td>{s.phone}</td>
                    <td className="text-end">
                      <button className="btn btn-sm btn-outline-primary me-2" onClick={() => handleEdit(s)}>Edit</button>
                      <button className="btn btn-sm btn-outline-danger" onClick={() => handleDelete(s)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}
